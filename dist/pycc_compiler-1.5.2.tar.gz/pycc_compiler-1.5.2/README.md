```bash
pycc --help
```
